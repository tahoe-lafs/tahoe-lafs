# -*- test-case-name: foolscap.test -*-
"""foolscap tests"""
