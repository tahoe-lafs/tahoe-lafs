"""
Library of useful Python functions and classes.

Projects that have contributed substantial portions to pyutil:
U{Mojo Nation<http://mojonation.net/>}
U{Mnet<http://sf.net/projects/mnet>}
U{Allmydata<http://allmydata.com/>}
U{Tahoe<http://allmydata.org/>}

mailto:zooko@zooko.com

pyutil web site: U{http://zooko.com/repos/pyutil}
"""

__version__ = "unknown"
try:
    from _version import __version__
except ImportError:
    # we're running in a tree that hasn't run darcsver.py, so we don't
    # know what our version is. This should not happen very often.
    pass
