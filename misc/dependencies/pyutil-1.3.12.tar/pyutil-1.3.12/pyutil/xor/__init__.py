from pyutil.xor import *
