#!/usr/bin/env python

# from the Python Standard Library
import sys, zlib

def main():
    fobj = open(sys.argv[1], "r")
    adlerval = 0
    data = fobj.read(65536)
    while data:
        adlerval = zlib.adler32(data, adlerval)
        data = fobj.read(65536)
    print "%x" % adlerval
 
if __name__ == '__main__':
    main()
