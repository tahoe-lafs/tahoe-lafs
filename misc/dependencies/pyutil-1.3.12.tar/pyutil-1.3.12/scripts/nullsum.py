#!/usr/bin/env python

# from the Python Standard Library
import sys, zlib

if __name__ == '__main__':
    fobj = open(sys.argv[1], "r")
    nullval = 0
    data = fobj.read(65536)
    while data:
        data = fobj.read(65536)
    print "%x" % nullval
 
