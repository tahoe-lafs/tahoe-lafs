#!/usr/bin/env python

# from the Python Standard Library (2.5)
import hashlib, sys

def main():
    for fn in sys.argv[1:]:
        fobj = open(fn, "r")
        hasher = hashlib.sha256()
        data = fobj.read(65536)
        while data:
            hasher.update(data)
            data = fobj.read(65536)
        digest = hasher.digest()
        print hashlib.sha256(digest).hexdigest()
 
if __name__ == '__main__':
    main()
