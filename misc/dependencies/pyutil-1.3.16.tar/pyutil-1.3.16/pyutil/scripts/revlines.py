#!/usr/bin/env python

# output the lines of a file in reverse order

import sys

if len(sys.argv) > 1:
    fname = sys.argv[1]
    inf = open(fname, 'r')
else:
    inf = sys.stdin

for l in reversed(inf.readlines()):
    sys.stdout.writelines(l)

