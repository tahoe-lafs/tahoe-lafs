import sys

from pyutil import find_exe

def main():
    cmd = find_exe.find_exe("trial")
    if cmd:
        print " ".join(cmd).replace("\\", "/")
    else:
        sys.exit(1)
