# Copyright (c) 2004 Divmod.
# See LICENSE for details.
