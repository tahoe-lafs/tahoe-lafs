locale = {
    "en" : {
        "defaultPage" : "index",
        "next" : "Next",
        "prev" : "Previous",
        "home" : "Home",
        "up" : "Up",
        "top" : "Return to Top",
        "toc" : "Table of Contents",
        "updatedOn" : "Last updated on",
        "sub" : "Subsections",
    }
}

